/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

import DTOS.ClienteDTO;
import DTOS.crearClienteDTO;
import PersistenciaUtil.PasswordUtil;
import PesistenciaDAO.ClienteDAO;
import entidad.clienteEntidad;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import persistencia.PersistenciaException;

/**
 *
 * @author urias
 */
public class clienteNegocio {
   private final ClienteDAO clienteDAO; 
   
   public clienteNegocio(){
       this.clienteDAO = new ClienteDAO();
   }
   
   public ClienteDTO login(String usuario, String contrasenaPlana) throws NegocioException {
        if (usuario == null || usuario.isBlank() || contrasenaPlana == null || contrasenaPlana.isBlank()) {
            throw new NegocioException("Usuario y contraseña son obligatorios.");
        }

        try {
            clienteEntidad c = clienteDAO.buscarPorUsuario(usuario);
            if (c == null || !PasswordUtil.verificar(contrasenaPlana, c.getContraseña())) {
                throw new NegocioException("Usuario o contraseña incorrectos.");
            }
            return aDTO(c);
        } catch (PersistenciaException e) {
            throw new NegocioException("No se pudo iniciar sesión: " + e.getMessage());
        }
    }
   
   private ClienteDTO aDTO(clienteEntidad c) {
        return new ClienteDTO(
                c.getId_cliente(),
                c.getNombres(),
                c.getApellidoPaterno(),
                c.getApellidoMaterno(),
                c.getFechaNacimiento() == null ? null : c.getFechaNacimiento().toString(),
                c.getUsuario(),
                null // nunca regresamos el hash de la contraseña hacia la UI
        );
    }
   
    public void registrar(crearClienteDTO datos) throws NegocioException {
        if (vacio(datos.getNombres()) || vacio(datos.getApellidoPaterno()) || vacio(datos.getApellidoMaterno())
                || vacio(datos.getUsuario()) || vacio(datos.getContraseña()) || vacio(datos.getFechaNacimiento())) {
            throw new NegocioException("Todos los campos son obligatorios.");
        }

        LocalDate fechaNacimiento;
        try {
            fechaNacimiento = LocalDate.parse(datos.getFechaNacimiento(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        } catch (DateTimeParseException e) {
            throw new NegocioException("La fecha de nacimiento debe tener el formato dd/MM/yyyy.");
        }

        try {
            if (clienteDAO.existe(datos.getUsuario())) {
                throw new NegocioException("Ese nombre de usuario ya existe, elige otro.");
            }

            clienteEntidad c = new clienteEntidad();
            c.setNombres(datos.getNombres());
            c.setApellidoPaterno(datos.getApellidoPaterno());
            c.setApellidoMaterno(datos.getApellidoMaterno());
            c.setFechaNacimiento(fechaNacimiento);
            c.setUsuario(datos.getUsuario());
            c.setContraseña(PasswordUtil.hash(datos.getContraseña()));

            clienteDAO.registrar(c);
        } catch (PersistenciaException e) {
            throw new NegocioException("No se pudo completar el registro: " + e.getMessage());
        }
    }
    
    private boolean vacio(String valor) {
        return valor == null || valor.isBlank();
    }
}
