/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PersistenciaUtil;
import org.mindrot.jbcrypt.BCrypt;
/**
 *
 * @author urias
 */
public class PasswordUtil {
    
    private PasswordUtil(){
        
    }
    
    public static String hash(String contrasenaPlana){
        return BCrypt.hashpw(contrasenaPlana, BCrypt.gensalt(10));
    }
    
    public static boolean verificar(String contrasenaPlana, String contrasenaHash) {
        try {
            return BCrypt.checkpw(contrasenaPlana, contrasenaHash);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
