/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author urias
 */
public class Conexion {
    private final String SERVER = "127.0.0.1";
    private final String PUERTO = "3306";
    private final String BASE_DATOS = "tuticket_db";
    private final String CADENA_CONEXION = "jdbc:mysql://" + SERVER + ":" + PUERTO + "/" + BASE_DATOS
            + "?useSSL=false&serverTimezone=America/Hermosillo&allowPublicKeyRetrieval=true";
    private final String USUARIO = "root";
    private final String CONTRASEÑA = "admin"; // <-- cambia esto por tu contraseña real de MySQL

    public Connection crearConexion() throws SQLException {
        Connection conexion = DriverManager.getConnection(CADENA_CONEXION, USUARIO, CONTRASEÑA);
        return conexion;
    }
}
