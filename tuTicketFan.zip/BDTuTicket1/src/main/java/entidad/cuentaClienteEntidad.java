/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class cuentaClienteEntidad {
    
    private int id_cuentaCliente;
    private String banco;
    private String numeroCuenta;
    private float saldo;

    public cuentaClienteEntidad() {
    }

    public cuentaClienteEntidad(String banco, String numeroCuenta, float saldo) {
        this.banco = banco;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }

    public cuentaClienteEntidad(int id_cuentaCliente, String banco, String numeroCuenta, float saldo) {
        this.id_cuentaCliente = id_cuentaCliente;
        this.banco = banco;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }

    public int getId_cuentaCliente() {
        return id_cuentaCliente;
    }

    public void setId_cuentaCliente(int id_cuentaCliente) {
        this.id_cuentaCliente = id_cuentaCliente;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "cuentaClienteEntidad{" + "id_cuentaCliente=" + id_cuentaCliente + ", banco=" + banco + ", numeroCuenta=" + numeroCuenta + ", saldo=" + saldo + '}';
    }
    
    
    
}
