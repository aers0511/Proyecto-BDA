/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class eventoEntidad {
    
    private int id_evento;
    private String nombreShow;
    private String tipoEvento;
    private int edadMinima;
    private String imagen;

    public eventoEntidad() {
    }

    public eventoEntidad(String nombreShow, String tipoEvento, int edadMinima, String imagen) {
        this.nombreShow = nombreShow;
        this.tipoEvento = tipoEvento;
        this.edadMinima = edadMinima;
        this.imagen = imagen;
    }

    public eventoEntidad(int id_evento, String nombreShow, String tipoEvento, int edadMinima, String imagen) {
        this.id_evento = id_evento;
        this.nombreShow = nombreShow;
        this.tipoEvento = tipoEvento;
        this.edadMinima = edadMinima;
        this.imagen = imagen;
    }

    public int getId_evento() {
        return id_evento;
    }

    public void setId_evento(int id_evento) {
        this.id_evento = id_evento;
    }

    public String getNombreShow() {
        return nombreShow;
    }

    public void setNombreShow(String nombreShow) {
        this.nombreShow = nombreShow;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public int getEdadMinima() {
        return edadMinima;
    }

    public void setEdadMinima(int edadMinima) {
        this.edadMinima = edadMinima;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "eventoEntidad{" + "id_evento=" + id_evento + ", nombreShow=" + nombreShow + ", tipoEvento=" + tipoEvento + ", edadMinima=" + edadMinima + ", imagen=" + imagen + '}';
    }
    
    
}
