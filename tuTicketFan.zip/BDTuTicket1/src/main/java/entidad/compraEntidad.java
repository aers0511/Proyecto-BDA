/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class compraEntidad {
    
    private int id_compra;
    private String fechaHora;
    private float precioFinal;
    private String estado;

    public compraEntidad() {
    }

    public compraEntidad(String fechaHora, float precioFinal, String estado) {
        this.fechaHora = fechaHora;
        this.precioFinal = precioFinal;
        this.estado = estado;
    }

    public compraEntidad(int id_compra, String fechaHora, float precioFinal, String estado) {
        this.id_compra = id_compra;
        this.fechaHora = fechaHora;
        this.precioFinal = precioFinal;
        this.estado = estado;
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public float getPrecioFinal() {
        return precioFinal;
    }

    public void setPrecioFinal(float precioFinal) {
        this.precioFinal = precioFinal;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "compraEntidad{" + "id_compra=" + id_compra + ", fechaHora=" + fechaHora + ", precioFinal=" + precioFinal + ", estado=" + estado + '}';
    }
    
    
}
