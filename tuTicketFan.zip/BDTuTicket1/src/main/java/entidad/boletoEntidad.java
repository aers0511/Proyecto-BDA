/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class boletoEntidad {
    
    private int id_boleto;
    private String codigoBoleto;
    private float precio;
    private String estado;

    public boletoEntidad() {
    }

    public boletoEntidad(String codigoBoleto, float precio, String estado) {
        this.codigoBoleto = codigoBoleto;
        this.precio = precio;
        this.estado = estado;
    }

    public boletoEntidad(int id_boleto, String codigoBoleto, float precio, String estado) {
        this.id_boleto = id_boleto;
        this.codigoBoleto = codigoBoleto;
        this.precio = precio;
        this.estado = estado;
    }

    public int getId_boleto() {
        return id_boleto;
    }

    public void setId_boleto(int id_boleto) {
        this.id_boleto = id_boleto;
    }

    public String getCodigoBoleto() {
        return codigoBoleto;
    }

    public void setCodigoBoleto(String codigoBoleto) {
        this.codigoBoleto = codigoBoleto;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "boletoEntidad{" + "id_boleto=" + id_boleto + ", codigoBoleto=" + codigoBoleto + ", precio=" + precio + ", estado=" + estado + '}';
    }
    
    
}
