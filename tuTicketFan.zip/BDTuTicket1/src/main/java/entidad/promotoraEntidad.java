/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class promotoraEntidad {
    
    private int id_promotora;
    private String nombreComercial;
    private String calle;
    private String numero;
    private String colonia;
    private String ciudad;
    private String estado;

    public promotoraEntidad() {
    }

    public promotoraEntidad(String nombreComercial, String calle, String numero, String colonia, String ciudad, String estado) {
        this.nombreComercial = nombreComercial;
        this.calle = calle;
        this.numero = numero;
        this.colonia = colonia;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    public promotoraEntidad(int id_promotora, String nombreComercial, String calle, String numero, String colonia, String ciudad, String estado) {
        this.id_promotora = id_promotora;
        this.nombreComercial = nombreComercial;
        this.calle = calle;
        this.numero = numero;
        this.colonia = colonia;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    public int getId_promotora() {
        return id_promotora;
    }

    public void setId_promotora(int id_promotora) {
        this.id_promotora = id_promotora;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "promotoraEntidad{" + "id_promotora=" + id_promotora + ", nombreComercial=" + nombreComercial + ", calle=" + calle + ", numero=" + numero + ", colonia=" + colonia + ", ciudad=" + ciudad + ", estado=" + estado + '}';
    }
    
    
}
