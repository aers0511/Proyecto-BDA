/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class operacionCuentaEntidad {
    
    private int id_operacion;
    private String tipoOperacion;
    private float monto;
    private String fechaHora;
    private float saldoEnterior;
    private float saldoNuevo;

    public operacionCuentaEntidad() {
    }

    public operacionCuentaEntidad(String tipoOperacion, float monto, String fechaHora, float saldoEnterior, float saldoNuevo) {
        this.tipoOperacion = tipoOperacion;
        this.monto = monto;
        this.fechaHora = fechaHora;
        this.saldoEnterior = saldoEnterior;
        this.saldoNuevo = saldoNuevo;
    }

    public operacionCuentaEntidad(int id_operacion, String tipoOperacion, float monto, String fechaHora, float saldoEnterior, float saldoNuevo) {
        this.id_operacion = id_operacion;
        this.tipoOperacion = tipoOperacion;
        this.monto = monto;
        this.fechaHora = fechaHora;
        this.saldoEnterior = saldoEnterior;
        this.saldoNuevo = saldoNuevo;
    }

    public int getId_operacion() {
        return id_operacion;
    }

    public void setId_operacion(int id_operacion) {
        this.id_operacion = id_operacion;
    }

    public String getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(String tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public float getSaldoEnterior() {
        return saldoEnterior;
    }

    public void setSaldoEnterior(float saldoEnterior) {
        this.saldoEnterior = saldoEnterior;
    }

    public float getSaldoNuevo() {
        return saldoNuevo;
    }

    public void setSaldoNuevo(float saldoNuevo) {
        this.saldoNuevo = saldoNuevo;
    }

    @Override
    public String toString() {
        return "operacionCuentaEntidad{" + "id_operacion=" + id_operacion + ", tipoOperacion=" + tipoOperacion + ", monto=" + monto + ", fechaHora=" + fechaHora + ", saldoEnterior=" + saldoEnterior + ", saldoNuevo=" + saldoNuevo + '}';
    }
    
    
    
}
