/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author urias
 */
public class cuentaPromotoraEntidad {
    private int id_cuenta;
    private String banco;
    private String numeroCuenta;
    private float saldo;

    public cuentaPromotoraEntidad() {
    }

    public cuentaPromotoraEntidad(String banco, String numeroCuenta, float saldo) {
        this.banco = banco;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }

    public cuentaPromotoraEntidad(int id_cuenta, String banco, String numeroCuenta, float saldo) {
        this.id_cuenta = id_cuenta;
        this.banco = banco;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }

    public int getId_cuenta() {
        return id_cuenta;
    }

    public void setId_cuenta(int id_cuenta) {
        this.id_cuenta = id_cuenta;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "cuentaPromotoraEntidad{" + "id_cuenta=" + id_cuenta + ", banco=" + banco + ", numeroCuenta=" + numeroCuenta + ", saldo=" + saldo + '}';
    }
    
    
    
}
