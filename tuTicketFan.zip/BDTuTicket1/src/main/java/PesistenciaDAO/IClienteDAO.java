/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PesistenciaDAO;

import entidad.clienteEntidad;
import java.sql.ResultSet;
import persistencia.PersistenciaException;

/**
 *
 * @author urias
 */
public interface IClienteDAO {
    
    boolean existe(String usuario) throws PersistenciaException;
    clienteEntidad buscarPorUsuario(String usuario) throws PersistenciaException;
    clienteEntidad buscarPorId(int id_cliente) throws PersistenciaException;
    clienteEntidad mapear(ResultSet rs) throws PersistenciaException;
    int registrar(clienteEntidad cliente) throws PersistenciaException;
}
