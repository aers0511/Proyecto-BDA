/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PesistenciaDAO;

import entidad.clienteEntidad;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import persistencia.Conexion;
import persistencia.IConexion;
import persistencia.PersistenciaException;

/**
 *
 * @author urias
 */
public class ClienteDAO implements IClienteDAO{

    private IConexion conexion;
    
    public ClienteDAO(IConexion conexion){
        this.conexion = conexion;
    }

    public ClienteDAO() {
        
    }
    
    
    
    @Override
    public clienteEntidad buscarPorId(int id) throws PersistenciaException {
       String sql = "SELECT * FROM cliente WHERE id_cliente = ?";
        try (Connection con = conexion.crearConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el cliente: " + e.getMessage());
        }
        return null;
    }

    

    @Override
    public clienteEntidad buscarPorUsuario(String usuario) throws PersistenciaException {
        String sql = "SELECT * FROM cliente WHERE usuario = ?";
        try (Connection con = conexion.crearConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al buscar el cliente: " + e.getMessage());
        }
        return null;
    }

    @Override
    public clienteEntidad mapear(ResultSet rs) throws PersistenciaException {
        try {
            clienteEntidad c = new clienteEntidad();
            c.setId_cliente(rs.getInt("id_cliente"));
            c.setNombres(rs.getString("nombres"));
            c.setApellidoPaterno(rs.getString("apellido_paterno"));
            c.setApellidoMaterno(rs.getString("apellido_materno"));
            Date fechaNacimiento = rs.getDate("fecha_nacimiento");
            c.setFechaNacimiento(fechaNacimiento == null ? null : fechaNacimiento.toLocalDate());
            c.setUsuario(rs.getString("usuario"));
            c.setContraseña(rs.getString("contrasena"));
            return c;
        } catch (SQLException e) {
            throw new PersistenciaException("Error al leer los datos del cliente: " + e.getMessage());
        }
    }

    @Override
    public boolean existe(String usuario) throws PersistenciaException {
        String sql = "SELECT 1 FROM cliente WHERE usuario = ?";
        try (Connection con = conexion.crearConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            throw new PersistenciaException("Error al verificar el usuario: " + e.getMessage());
        }
    }

    @Override
    public int registrar(clienteEntidad cliente) throws PersistenciaException {
        String sql = "{call sp_registrar_cliente(?,?,?,?,?,?,?)}";
        try (Connection con = conexion.crearConexion();
             CallableStatement cs = con.prepareCall(sql)) {
            cs.setString(1, cliente.getNombres());
            cs.setString(2, cliente.getApellidoPaterno());
            cs.setString(3, cliente.getApellidoMaterno());
            cs.setDate(4, Date.valueOf(cliente.getFechaNacimiento()));
            cs.setString(5, cliente.getUsuario());
            cs.setString(6, cliente.getContraseña());
            cs.registerOutParameter(7, Types.INTEGER);
            cs.execute();
            return cs.getInt(7);
        } catch (SQLException e) {
            throw new PersistenciaException("Error al registrar el cliente: " + e.getMessage());
        }
    }
    
}
