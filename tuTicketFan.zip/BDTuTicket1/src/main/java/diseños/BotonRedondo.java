/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diseños;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JButton;

/**
 *
 * @author urias
 */
public class BotonRedondo extends JButton{
    
    
    private Color colorNormal = new Color(0, 105, 180);
    private Color colorHover = new Color(0,125,210);
    private Color colorSeleccionado = new Color(0,135,201);
    
    private boolean seleccionado = false;
    
    public BotonRedondo(){
        super();

        setForeground(Color.WHITE);
        setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 15));

        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);

        setCursor(new Cursor(Cursor.HAND_CURSOR));

        
        addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (!seleccionado) {
                    repaint();
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                repaint();
            }
        });
    }
    
    public void setSeleccionado(boolean seleccionado){
        this.seleccionado = seleccionado;
        repaint();
    }
    
    @Override
    protected void paintComponent(Graphics g){
        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
        );

        Color color;

        if (seleccionado) {
            color = colorSeleccionado;
        } else if (getModel().isRollover()) {
            color = colorHover;
        } else {
            color = colorNormal;
        }

        g2.setColor(color);

        g2.fillRoundRect(
                0,
                0,
                getWidth(),
                getHeight(),
                12,
                12
        );

        g2.dispose();

        super.paintComponent(g);
    }
}
