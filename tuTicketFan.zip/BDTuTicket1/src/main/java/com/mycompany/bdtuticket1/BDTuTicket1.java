/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bdtuticket1;

import presentacion.InicioSesion;
import presentacion.RegistroCliente;

/**
 *
 * @author urias
 */
public class BDTuTicket1 {

    public static void main(String[] args) {
        
        java.awt.EventQueue.invokeLater(() -> new InicioSesion().setVisible(true));
    }
}
